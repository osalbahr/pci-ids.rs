# Changelog

All notable changes to `pci-ids` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

<!-- @next-header@ -->

## [0.2.5] - 2022-11-25

### Added

* Match package version with Docs.rs

## [0.2.4] - 2022-11-25

### Added

* Update module to latest version
* Update pci-ids list to snapshot 2022-11-25

## [0.2.3] - 2022-06-24

### Added

* Fork `usb-ids` and modifiy to `pci-ids` 
